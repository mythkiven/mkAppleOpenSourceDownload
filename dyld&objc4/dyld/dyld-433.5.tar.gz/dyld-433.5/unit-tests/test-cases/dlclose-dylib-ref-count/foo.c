
int foo()
{
	return 10;
}
