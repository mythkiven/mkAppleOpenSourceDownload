__attribute__((weak))
int mydata;


int foo()
{
	return mydata;
}
