
extern int y;

int test()
{
	return y;
}
