

void foo() __attribute__((weak));

void foo()
{
}

void abcdefghijklmnopqrstuvwxzy() {}
void abcde3fghijklmnopqrstuvwxzy() {}
void abcdef4ghijklmnopqrstuvwxzy() {}
void abcdefgh5ijklmnopqrstuvwxzy() {}
void abcdefghij6klmnopqrstuvwxzy() {}
void abcdefghijk7lmnopqrstuvwxzy() {}
void abcdefghijklm8nopqrstuvwxzy() {}
void abcdefghijklmn9opqrstuvwxzy() {}
void a1bcdefghijklmnopqrstuvwxzy() {}
void a2bcdefghijklmnopqrstuvwxzy() {}
void a3bcdefghijklmnopqrstuvwxzy() {}
void a4bcdefghijklmnopqrstuvwxzy() {}
void a5bcdefghijklmnopqrstuvwxzy() {}
void a6bcdefghijklmnopqrstuvwxzy() {}
void a7bcdefghijklmnopqrstuvwxzy() {}
void a8bcdefghijklmnopqrstuvwxzy() {}
void a9bcdefghijklmnopqrstuvwxzy() {}
void ab1cdefghijklmnopqrstuvwxzy() {}
void ab2cdefghijklmnopqrstuvwxzy() {}
void ab3cdefghijklmnopqrstuvwxzy() {}
void ab4cdefghijklmnopqrstuvwxzy() {}
void ab5cdefghijklmnopqrstuvwxzy() {}
void ab6cdefghijklmnopqrstuvwxzy() {}
void ab7cdefghijklmnopqrstuvwxzy() {}
void ab8cdefghijklmnopqrstuvwxzy() {}
void ab9cdefghijklmnopqrstuvwxzy() {}
void abc1defghijklmnopqrstuvwxzy() {}
void abc2defghijklmnopqrstuvwxzy() {}
void abc3defghijklmnopqrstuvwxzy() {}
void abc4defghijklmnopqrstuvwxzy() {}
void abc5defghijklmnopqrstuvwxzy() {}
void abc6defghijklmnopqrstuvwxzy() {}
void abc7defghijklmnopqrstuvwxzy() {}
void abc8defghijklmnopqrstuvwxzy() {}
void abc9defghijklmnopqrstuvwxzy() {}
void abcd1efghijklmnopqrstuvwxzy() {}
void abcd2efghijklmnopqrstuvwxzy() {}
void abcd3efghijklmnopqrstuvwxzy() {}
void abcd4efghijklmnopqrstuvwxzy() {}
void abcd5efghijklmnopqrstuvwxzy() {}
void abcd6efghijklmnopqrstuvwxzy() {}
void abcd7efghijklmnopqrstuvwxzy() {}
void abcd8efghijklmnopqrstuvwxzy() {}
void abcd9efghijklmnopqrstuvwxzy() {}
void abcde1fghijklmn9opqrstuvwxzy() {}
void abcde2fghijklmn9opqrstuvwxzy() {}
void abcde3fghijklmn9opqrstuvwxzy() {}
void abcde4fghijklmn9opqrstuvwxzy() {}
void abcde5fghijklmn9opqrstuvwxzy() {}
void abcde6fghijklmn9opqrstuvwxzy() {}
void abcde7fghijklmn9opqrstuvwxzy() {}
void abcde8fghijklmn9opqrstuvwxzy() {}
void abcde9fghijklmn9opqrstuvwxzy() {}
