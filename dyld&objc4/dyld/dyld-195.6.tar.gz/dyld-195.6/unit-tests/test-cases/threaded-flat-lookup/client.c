
extern void foo();
extern void bar();
extern void baz();

void doit()
{
	foo();
	bar();
	baz();
}
