
namespace dyld3 {

struct ClosureBuffer { };

ClosureBuffer closured_CreateImageGroup(const ClosureBuffer& input)
{
    return ClosureBuffer();
}


} // namespace dyld3
