extern int getdown();

