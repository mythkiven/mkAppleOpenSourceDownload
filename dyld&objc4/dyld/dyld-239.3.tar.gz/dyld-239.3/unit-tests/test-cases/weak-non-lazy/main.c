

// put test code in a dylib so that is slides
extern void realmain();

int main()
{
	realmain();
	return 0;
}


