#include <stdbool.h>

extern void setB();
extern void setU();
extern void setU2();

extern bool ok();

