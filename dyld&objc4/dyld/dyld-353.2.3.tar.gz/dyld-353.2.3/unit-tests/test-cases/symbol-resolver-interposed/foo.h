
extern int foo();
extern void set_foo(int);
