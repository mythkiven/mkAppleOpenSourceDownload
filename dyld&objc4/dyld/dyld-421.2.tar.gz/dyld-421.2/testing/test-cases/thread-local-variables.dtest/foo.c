


__thread int a;
__thread int b = 5;



