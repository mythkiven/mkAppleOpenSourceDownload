#include <stdbool.h>

extern void setB();
extern void setU();

extern bool ok();

