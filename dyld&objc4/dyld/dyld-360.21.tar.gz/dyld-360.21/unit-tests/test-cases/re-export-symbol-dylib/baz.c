int baz() 
{
  return 3;
}

