
namespace dyld3 {

struct ClosureBuffer { int x; };

ClosureBuffer closured_CreateImageGroup(const ClosureBuffer& input)
{
    return ClosureBuffer();
}


} // namespace dyld3
