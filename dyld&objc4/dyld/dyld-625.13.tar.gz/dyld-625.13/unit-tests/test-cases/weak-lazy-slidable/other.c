#include <stdbool.h>

bool bar2()
{
	return false;
}

